module.exports = api => {
    api.cache(true);

    const presets = [
        '@babel/preset-react',
        '@babel/preset-env'
    ];

    const plugins = [
        '@babel/plugin-proposal-class-properties',
        [
            'babel-plugin-import',
            {
                'libraryName': '@material-ui/core',
                // Use "'libraryDirectory': ''," if your bundler does not support ES modules
                'libraryDirectory': 'esm',
                'camel2DashComponentName': false
            },
            'core'
        ],
        [
            'babel-plugin-import',
            {
                'libraryName': '@material-ui/icons',
                // Use "'libraryDirectory': ''," if your bundler does not support ES modules
                'libraryDirectory': 'esm',
                'camel2DashComponentName': false
            },
            'icons'
        ]
    ];

    return {
        presets,
        plugins
    };
}