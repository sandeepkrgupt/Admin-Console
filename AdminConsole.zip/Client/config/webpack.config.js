const path = require('path');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');

//const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;

const CWD = process.cwd();

module.exports = env => {
    const ret = {
        context: path.resolve(CWD, 'src'),
        externals: {
            "react": "React",
            "react-dom": "ReactDOM",
            "redux": "Redux",
            "react-redux": "ReactRedux",
            "whatwg-fetch": "fetch",
            "lodash": "_",
        },
        plugins: [
            new CleanWebpackPlugin()            
        ]
    };

    //mode
    switch (env.NODE_ENV) {
        case 'local':
        case 'dev':
            ret.mode = 'development';
            ret.devtool = 'inline-source-map';
            ret.devServer = {
                contentBase: path.join(__dirname, '../dist'),
                compress: true,
                port: 9000
            }
            ret.plugins.push(new HtmlWebpackPlugin({ template: '../index.pug', isProd: false }))
            //ret.plugins.push(new BundleAnalyzerPlugin())
            break;
        case 'qat':
        case 'uat':
        case 'live':
            ret.mode = 'production';
            break;
    }

    //entry
    ret.entry = {
        'dpmac': './app.container.js',
    };

    //output
    ret.output = {
        filename: '[name].app.js',
        path: path.resolve(CWD, 'dist')
    };

    //modules
    ret.module = {
        rules: [
            { test: /\.jsx?$/, exclude: /node_modules/, loader: 'babel-loader', options: { configFile: path.resolve(CWD, 'config/babel.config.js') } },
            { test: /\.pug$/, exclude: /node_modules/, loader: "pug-loader", options: { self: true } },
            {
                test: /\.css$/,
                exclude: /node_modules/,
                use: [
                    { loader: 'style-loader' },
                    { loader: 'css-loader' },
                    { loader: 'postcss-loader', options: {config: {path:"./config"}}}
                ]
            },
            { test: /\.(png|jpg|svg|gif)$/, use: ['file-loader'] }
        ]
    };

    return ret;
}