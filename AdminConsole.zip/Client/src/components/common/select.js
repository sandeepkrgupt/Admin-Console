import { Select, MenuItem } from '@material-ui/core'

export default ({ selectedVal, onChange, items }) => {
  return (
    <Select
      value={selectedVal || items[0].val}
      onChange={(e) => {
        onChange(e.target.value)
      }}
      displayEmpty
    >
      {items.map(item => <MenuItem key={item.val} value={item.val}>{item.title}</MenuItem>)}
    </Select>
  )
}