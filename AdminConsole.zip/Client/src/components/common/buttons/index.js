import {Button} from '@material-ui/core'
export const PrimaryButton = (props) => {
  return <Button variant="contained" color="primary" {...props} />
}

export const SecondaryButton = (props) => {
  return <Button color="secondary" {...props} />
}

export const CustomBackButton = (props) => {
  return <Button color="default" {...props} />
}