import {TextField} from '@material-ui/core'
import _ from 'lodash'

export default ({label, debouncedBy, onChange}) => {
  let debouncedChange = onChange;
  if(debouncedBy) {
    debouncedChange = _.debounce(onChange, debouncedBy)
  }
  return <TextField label={label} onChange={e => {
    debouncedChange(e.target.value)
  }}/>
} 