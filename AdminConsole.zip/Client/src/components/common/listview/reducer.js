const reducer = (state, action) => {
  switch (action.type) {
    case 'onSearch':
      return {
        ...state,
        search: {
          ...state.search,
          val: action.payload,
          results: action.payload ? state.rows.filter(row => {
            let matchFound = false;
            for (let field in row) {
              if (!field.startsWith("_")) {
                if (row[field].indexOf(search.val) != -1) {
                  matchFound = true;
                  break;
                }      
              }
            }
            return matchFound
          }) : []

        }
      };
    case 'onSort':
      return {
        ...state,
        search: {
          ...state.search,
          val: action.payload
        }
      };
    case 'onChangePage':
      return {
        ...state,
        paging: {
          ...state.paging,
          page: action.payload
        }
      };
    case 'onChangeRowsPerPage':
      return {
        ...state,
        paging: {
          ...state.paging,
          rowsPerPage: action.payload
        }
      };
    default:
      throw new Error({ type: "unsupported action", action });
  }
}

export default reducer