export const getInitialStateFromProps = ({ rows, cols, orderBy, rowsPerPageOptions }) => ({
  search: {
    val: "",
    results: []
  },
  sort: {
    order: 'ASC',
    orderBy
  },
  rows: rows || [],
  cols: cols || [],
  paging: {
    rowsPerPageOptions,
    rowsPerPage: rowsPerPageOptions[0],
    page: 0
  }
})