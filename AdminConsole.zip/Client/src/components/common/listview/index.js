import React, { useReducer } from 'react';
import Table from '../table'

import reducer from './reducer'
import { getInitialStateFromProps } from './state'


import TextBox from '../textbox'
import Select from '../select'

const ListView = ({ rows, cols, onSelect, onAction, orderBy = 0, rowsPerPageOptions = [5, 10, 20, 50, 100] }) => {
  const [state, dispatch] = useReducer(reducer, getInitialStateFromProps({ rows, cols, orderBy, rowsPerPageOptions }))

  let rowsToRender = rows;

  //search
  if (state.search.val) {
    rowsToRender = rows.filter(row => {
      let matchFound = false;
      for (let field in row) {
        if (!field.startsWith("_")) {
          if (row[field].indexOf(state.search.val) != -1) {
            matchFound = true;
            break;
          }
        }
      }
      return matchFound
    })
  }

  //sort

  //paging
  rowsToRender = rowsToRender.slice(state.paging.page * state.paging.rowsPerPage, state.paging.page * state.paging.rowsPerPage + state.paging.rowsPerPage)


  return (<>
    <div>
      <TextBox
        label="Search"
        debouncedBy={500}
        onChange={(searchVal) => {
          dispatch({ type: "onSearch", payload: searchVal })
        }} />
    </div>

    <div>
      <Table
        rows={rowsToRender}
        cols={cols}
        sort={state.sort}
        paging={state.paging}
        onSelect={onSelect}
        onAction={(action) => {
          try {
            dispatch(action)
          }
          catch (e) {
            onAction(action)
          }

        }} />
    </div>
  </>)
}

export default ListView;