import React from 'react';

import { Table, TableBody, TableCell, TableHead, TableRow, TableContainer, TablePagination } from '@material-ui/core';


export default ({ rows, cols, sort, paging, onSelect, onAction }) => {
  //sort

  //paging

  return (<><TableContainer>
    <Table>
      <TableHead>
        <TableRow>
          {cols.map((col, i) => <TableCell key={i}>{col.title}</TableCell>)}
        </TableRow>
      </TableHead>
      <TableBody>
        {rows
          .map(row => <TableRow key={row.id} onDoubleClick={() =>{
            onSelect(row)
          }} >
            {cols.map((col, i) => <TableCell key={i}>
              {row[col.mappedTo]}
            </TableCell>)}
          </TableRow>)}
      </TableBody>
    </Table>
    <TablePagination
      rowsPerPageOptions={paging.rowsPerPageOptions}
      component="div"
      count={rows.length}
      rowsPerPage={paging.rowsPerPage}
      page={paging.page}
      onChangePage={(e, v) => {
        onAction({ type: "onChangePage", payload: v })
      }}
      onChangeRowsPerPage={(event) => {
        onAction({ type: 'onChangeRowsPerPage', payload: event.target.value })
      }}
    />

  </TableContainer>
  </>)
}