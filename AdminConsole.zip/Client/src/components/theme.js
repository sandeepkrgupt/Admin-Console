import { createMuiTheme, responsiveFontSizes } from '@material-ui/core/styles';
import {purple, grey, red} from '@material-ui/core/colors';

const theme = createMuiTheme({
  palette: {
    // primary: purple,
    primary: {
      main: '#fff',
    },
    background: {
      default: "#fff",
    },  
    secondary: grey,
  },
  status: {
    danger: red,
  },
  overrides: {
    MuiDrawer: {
      paper: {
        background: '#0c3c7c',
        width: '25%',
        height: 'auto'
        // overflowY: 'hidden',
      },
    },
  },
});

const responsiveOpts = {
  breakpoints: ['sm', 'md', 'lg'],
  disableAlign: false,
  factor: 2
}

export default responsiveFontSizes(theme, responsiveOpts);

