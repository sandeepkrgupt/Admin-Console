import React from 'react';
import {
  Drawer, List, ListItem, ListItemText, Divider
} from '@material-ui/core';
import {
  NavLink, Link
} from "react-router-dom";
const appNav = (props) => (

  <Drawer open={props.showNav} onClose={props.unsetNavigation}>
    {/* <List>
      {props.navData.map((navDatum, i) => (
        <ListItem style={{ paddingTop: '0', paddingLeft:'2', margin: '1'}} button key={i} onClick={() => {
          props.unsetNavigation()
        }}>
          <ListItemText>
            <NavLink style={{ color: '#FFF', textDecoration: 'none'}} to={navDatum.route}>{navDatum.title}</NavLink>
          </ListItemText>
        </ListItem>
      ))}
    </List> */}
    <List component="nav" disablePadding>
      <ListItem button style={{ paddingLeft: 40, paddingTop: 40, height: 40 }} >
        <ListItemText style={{ color: '#FFF',textDecoration: 'underline' }} primary="Payment profile" />
      </ListItem>
      <ListItem button style={{ paddingLeft: 80,paddingTop:20, height: 40 }} >
        <ListItemText style={{ color: '#FFF' }} primary="Legal Entity" />
      </ListItem>
      <ListItem button style={{ paddingLeft: 80, height: 40 }} >
        <ListItemText style={{ color: '#FFF' }} primary="Merchant configuration" />
      </ListItem>
      <ListItem button style={{ paddingLeft: 80, height: 40 }} >
        <ListItemText style={{ color: '#FFF' }} primary="Raisenow widget" />
      </ListItem>
      <div style={{ paddingLeft: 40, paddingRight: 40, }}><Divider style={{ backgroundColor: '#FFF' }} /></div>
      <ListItem button style={{ paddingLeft: 40, paddingTop: 20, height: 40 }} >
        <ListItemText style={{ color: '#FFF',textDecoration: 'none' }} primary="Payment profile member" />
      </ListItem>
      <ListItem button style={{ paddingLeft: 80, height: 40 }} >
        <ListItemText style={{ color: '#FFF' }} primary="Country" />
      </ListItem>
      <ListItem button component={Link} to={'/currency'} onClick={() => {props.unsetNavigation()}}  
                style={{ paddingLeft: 80, height: 40 }}>
        <ListItemText style={{ color: '#FFF' }} primary="Currency" />
      </ListItem>
      <ListItem style={{ paddingLeft: 80,  height: 40 }}>
        <ListItemText style={{ color: '#FFF' }} primary="Transaction flow" />
      </ListItem>
      <ListItem style={{ paddingLeft: 80, height: 40  }}>
        <ListItemText style={{ color: '#FFF' }} primary="Transaction type" />
      </ListItem>
      <ListItem style={{ paddingLeft: 80, height: 40  }}>
        <ListItemText style={{ color: '#FFF' }} primary="Country currency mapping" />
      </ListItem>
      <div style={{ paddingLeft: 40, paddingRight: 40, }}><Divider style={{ backgroundColor: '#FFF' }} /></div>
      <ListItem style={{ paddingLeft: 40,paddingTop: 20, height: 40}}>
        <ListItemText style={{ color: '#FFF' }} primary="Bank account" />
      </ListItem>
      <ListItem style={{ paddingLeft: 40, height: 40}}>
        <ListItemText style={{ color: '#FFF' }} primary="Bank account assignment" />
      </ListItem>
      <ListItem style={{ paddingLeft: 40, height: 40}}>
        <ListItemText style={{ color: '#FFF' }} primary="Request source" />
      </ListItem>
      <ListItem style={{ paddingLeft: 40, height: 40}}>
        <ListItemText style={{ color: '#FFF' }} primary="Privacy policy" />
      </ListItem>
    </List>
  </Drawer>
);
export default appNav;
