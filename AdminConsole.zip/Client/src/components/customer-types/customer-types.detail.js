import React from 'react'
import { FormControl, FormLabel, RadioGroup, FormControlLabel, Radio, TextField, Paper } from '@material-ui/core'
import { PrimaryButton } from '../common/buttons'


const CustomerTypeDetail = ({ customerType }) => {
  console.log(customerType)
  return (
    <>
      <Paper>
        <div>
          <TextField
            label="Customer Code"
            InputProps={{
              readOnly: true,
            }}
            value={customerType.id}
          />
        </div>
        <div>
          <TextField
            label="Customer Type"
            InputProps={{
              readOnly: true,
            }}
            value={customerType.type}
          />
        </div>
        <div>
          <TextField
            label="Customer Subtype"
            InputProps={{
              readOnly: true,
            }}
            value={customerType.subtype}
          />
        </div>
        <div>
          <FormControl component="fieldset">
            <FormLabel component="legend">Status</FormLabel>
            <RadioGroup name="status" value={customerType.status}>
              <FormControlLabel value="active" control={<Radio />} label="Active" />
              <FormControlLabel value="inactive" control={<Radio />} label="Inactive" />
            </RadioGroup>
          </FormControl>
        </div>
        <div>
          <PrimaryButton onClick={() => {

          }}>EDIT</PrimaryButton>
        </div>
      </Paper>



    </>
  )
}

export default CustomerTypeDetail