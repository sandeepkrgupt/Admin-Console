import React from 'react'
import {Formik} from 'formik'

export default (props) => {
  const {customerType} = props;
  return <Formik
    initialValues={{...customerType}}
    validate={values => {
      const errors = {};
      if (!values.code) {
        errors.code = 'Required';
      }
      if (!values.type) {
        errors.type = "Required"
      }
      if (!values.subtype) {
        errors.subtype = "Required"
      }
      if (!values.status) {
        errors.status = "Required"
      }
      return errors;
    }}

  >
    {props.children}
  </Formik>

} 