import React, { useReducer } from 'react';
import { FormControl, FormLabel, RadioGroup, FormControlLabel, FormHelperText, Radio, TextField } from '@material-ui/core'
import { PrimaryButton, SecondaryButton } from '../common/buttons'
import { Link, useRouteMatch } from 'react-router-dom'
import CustomerTypesAddEditFormik from './customer-types.add-edit.formik'
const CustomerTypesAddEdit = ({ customerType, onCancel }) => {

  return (<>
    <div>
      <SecondaryButton component={Link} to={'/customer-types'}>Back to Customer Types</SecondaryButton>
    </div>
    <CustomerTypesAddEditFormik customerType={customerType}>
      {({
        values,
        errors,
        touched,
        handleChange,
        handleBlur,
        handleSubmit,
        isSubmitting,
      }) => (
          <form noValidate autoComplete='off'>
            <h1>Add Customer Type</h1>
            <div>
              <TextField name="code" required label="Customer Code" onChange={handleChange} value={values.code} onBlur={handleBlur} />
            </div>
            <div>
              <TextField name="type" required label="Customer Type" onChange={handleChange} value={values.type} onBlur={handleBlur} />
            </div>
            <div>
              <TextField name="subtype" required label="Customer Subtype" onChange={handleChange} value={values.subtype} onBlur={handleBlur} />
            </div>
            <div>
              <FormControl component="fieldset">
                <FormLabel component="legend">Status</FormLabel>
                <RadioGroup name="status" value={values.active} onChange={handleChange}>
                  <FormControlLabel value="active" control={<Radio />} label="Active" />
                  <FormControlLabel value="inactive" control={<Radio />} label="Inactive" />
                </RadioGroup>
              </FormControl>
            </div>
            <div>
              <PrimaryButton onClick={() => {
                handleSubmit();
              }}>Save</PrimaryButton>
            </div>
            <div>
              <SecondaryButton onClick={onCancel}>Cancel</SecondaryButton>
            </div>
          </form>
        )}
    </CustomerTypesAddEditFormik>
  </>)
}

export default CustomerTypesAddEdit