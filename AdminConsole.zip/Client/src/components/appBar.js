import React from 'react';
import {AppBar, Toolbar, Typography, IconButton,} from '@material-ui/core';
import MenuIcon from '@material-ui/icons/Menu';
// import logo from './images/rotary-logo-color-2019-simplified.svg';
///* <img src={logo} alt="logo" className={classes.logo} /> */


const appBar = (props) => (
  <AppBar position="static" >
    <Toolbar >
      <IconButton aria-label="menu" onClick={props.setNavigation}>
        <MenuIcon /> 
      </IconButton>
      <img src="https://www.rotary.org/sites/all/themes/rotary_rotaryorg/images/rotary-logo-color-2019-simplified.svg" alt="Rotary International" height="10%" width="10%"></img>
      <Typography variant="h6">
      &nbsp;&nbsp;Donation & Payment Administration  
      </Typography>
    </Toolbar>
  </AppBar>
);

export default appBar;
