import actionCreators from '../actions/actionCreators'
const thunkCreators_customerTypes = {
  createThunk_CustomerTypes_LIST: () => {
    return (dispatch, getState) =>  {
      setTimeout(() => {
        dispatch(actionCreators.CUSTOMER_TYPES.createAction_setList([
          { id: "1", type: "Individual", subtype: "Individual", status: "active", lastModified: "23:59 31-Dec-20" },
          { id: "2", type: "Organization", subtype: "Business", status: "active", lastModified: "23:59 31-Dec-20" },
          { id: "3", type: "Organization", subtype: "Rotary Club", status: "active", lastModified: "23:59 31-Dec-20" }
        ]))
      }, 1000)
    }
  }
}

export default thunkCreators_customerTypes