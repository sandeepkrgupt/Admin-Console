import customerTypesThunks from './customer-types.thunk'
import currencyTypesThunks from './currency.thunk'
export default {
  customerTypes: {
    ...customerTypesThunks
  }, 
  currencytypes:{
    ...currencyTypesThunks
  }
}