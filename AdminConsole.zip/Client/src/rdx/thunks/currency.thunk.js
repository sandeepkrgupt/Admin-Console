import axios from "axios";
import actionCreators from '../actions/actionCreators'

var user = "ogadmin";
var pass = `gC(u2>$L(w'"&`
var authorizationBasic = window.btoa(user + ':' + pass);
var defaultRequestConfig = {
  "headers": {
      "Authorization": "Basic " + authorizationBasic,
  }
};

const thunkCreators_currency = {
  createThunk_Currency_LIST: () => {
    return (dispatch, getState) => {
      setTimeout(() => {
        axios.get('https://cors-anywhere.herokuapp.com/https://dpmadminuat.rotaryintl.org/api/v1.1/currency', defaultRequestConfig)
          .then(response => {
            console.log(response.data)
            dispatch(actionCreators.CURRENCY.createAction_currency_setList(response.data))
          })
          .catch(error => {
            console.log(error.message)
          })

      }, 1000)
      // setTimeout(() => {
      //   dispatch(actionCreators.CURRENCY.createAction_currency_setList([
      //     { CurrencyKey: "46ea99a8-ec67-4487-a405-04337d97dd3f", CurrencyName: "TestDollar12", CurrencyCode: "Test", IsDeleted: "active", DateModified: "23:59 31-Dec-20" },
      //     { CurrencyKey: "a7ed6a4a-ae0f-4667-847f-05ba55f57ff3", CurrencyName: "Organization", CurrencyCode: "Business", IsDeleted: "active", DateModified: "23:59 31-Dec-20" },
      //     { CurrencyKey: "b0ffbcdf-3e8e-41a9-9494-0d22d3aca6f7", CurrencyName: "Norwegian Krone", CurrencyCode: "NOK", IsDeleted: "active", DateModified: "23:59 31-Dec-20" }
      //   ]))
      // }, 1000)
    }
  }
}

export default thunkCreators_currency