import actionTypes from './actionTypes';

const actionCreators = {
  NOTIFICATION: {
    createAction_setNotification(notificationMessage) {
      return {
        type: actionTypes.NOTIFICATION.SET_NOTIFICATION,
        payload: { notificationMessage },
      };
    },
    createAction_unsetNotification() {
      return {
        type: actionTypes.NOTIFICATION.UNSET_NOTIFICATION,
        payload: {},
      };
    },
  },
  UI: {

    createAction_workInProgress() {
      return {
        type: actionTypes.UI.WIP,
        payload: {},
      };
    },
    createAction_noWorkInProgress() {
      return {
        type: actionTypes.UI.NWIP,
        payload: {},
      };
    },
    createAction_setNavigation() {
      return {
        type: actionTypes.UI.SET_NAVIGATION,
        payload: {},
      };
    },
    createAction_unsetNavigation() {
      return {
        type: actionTypes.UI.UNSET_NAVIGATION,
        payload: {},
      };
    },
  },
  CUSTOMER_TYPES: {
    createAction_setList(list) {
      return {
        type: actionTypes.CUSTOMER_TYPES.SET_LIST,
        payload: list
      }
    },
    createAction_select(id) {
      return {
        type: actionTypes.CUSTOMER_TYPES.SELECT,
        payload: id
      }
    },
    createAction_unselect() {
      return {
        type: actionTypes.CUSTOMER_TYPES.SELECT,
        payload: {}
      }
    }
  },
  CURRENCY:{
    createAction_currency_setList(list) {
      return {
        type: actionTypes.CURRENCY.SET_LIST,
        payload: list
      }
    },
    createAction_currency_select(id) {
      return {
        type: actionTypes.CURRENCY.SELECT,
        payload: id
      }
    },
    createAction_currency_unselect() {
      return {
        type: actionTypes.CURRENCY.UNSELECT,
        payload: {}
      }
    }
  }
};

export default actionCreators;
