import actionTypes from '../actions/actionTypes';

const initialState = {
  notificationOpen: false,
  notificationMessage: null,
};

const notificationReducer = (prevState = initialState, action) => {
  const newState = {};
  switch (action.type) {
    case actionTypes.NOTIFICATION.SET_NOTIFICATION:
      newState.notificationOpen = true;
      newState.notificationMessage = action.payload.notificationMessage;
      break;
    case actionTypes.NOTIFICATION.UNSET_NOTIFICATION:
      newState.notificationOpen = false;
      newState.notificationMessage = null;
      break;
    default:
      break;
  }
  return {
    ...prevState,
    ...newState,
  };
};

export default notificationReducer;
