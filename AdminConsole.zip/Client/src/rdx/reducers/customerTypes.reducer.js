import actionTypes from '../actions/actionTypes';

const initialState = {
  list: [],
  selectedId: null,
  add: null
};
const reducer = (prevState = initialState, action) => {
  switch (action.type) {
    case actionTypes.CUSTOMER_TYPES.SET_LIST:
      return { ...prevState, list: action.payload }
    case actionTypes.CUSTOMER_TYPES.SELECT:
      return { ...prevState, selectedId: action.payload }
    case actionTypes.CUSTOMER_TYPES.UNSELECT:
      return { ...prevState, selectedId: null }
    default:
      return { ...prevState }
  }

};

export default reducer;
