import { combineReducers } from 'redux';

import ui from './ui.reducer';
import notification from './notification.reducer';
import customerTypes from './customerTypes.reducer';
import currency from './currency.reducer';

export default combineReducers({ ui, notification, customerTypes, currency });
