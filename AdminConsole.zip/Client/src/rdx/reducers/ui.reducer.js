import actionTypes from '../actions/actionTypes';

const initialStateUIReducer = {
  showLoading: false,
  showNav: false,
};
const uiReducer = (prevState = initialStateUIReducer, action) => {
  const newState = {};
  switch (action.type) {
    case actionTypes.UI.WIP:
      newState.showLoading = true;
      break;
    case actionTypes.UI.NWIP:
      newState.showLoading = false;
      break;
    case actionTypes.UI.SET_NAVIGATION:
      newState.showNav = true;
      break;
    case actionTypes.UI.UNSET_NAVIGATION:
      newState.showNav = false;
      break;
    default:
      break;
  }
  return {
    ...prevState,
    ...newState,
  };
};

export default uiReducer;
