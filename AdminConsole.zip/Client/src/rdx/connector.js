import { connect } from 'react-redux';
import actionCreators from './actions/actionCreators';
import thunkCreators from './thunks';

const mapStateToProps = (state) => ({
  ...state,
});

const mapDispatchToProps = (dispatch) => ({
  setNotification: (notificationMessage) => {
    dispatch(actionCreators.NOTIFICATION.createAction_setNotification(notificationMessage));
  },
  unsetNotification: () => {
    dispatch(actionCreators.NOTIFICATION.createAction_unsetNotification());
  },
  setWorkInProgress: () => {
    dispatch(actionCreators.UI.createAction_workInProgress());
  },
  setNoWorkInProgress: () => {
    dispatch(actionCreators.UI.createAction_noWorkInProgress());
  },
  setNavigation: () => {
    dispatch(actionCreators.UI.createAction_setNavigation());
  },
  unsetNavigation: () => {
    dispatch(actionCreators.UI.createAction_unsetNavigation());
  },
  fetchCustomerTypes: () => {
    dispatch(thunkCreators.customerTypes.createThunk_CustomerTypes_LIST())
  },
  selectCustomerType: (id) => {
    dispatch(actionCreators.CUSTOMER_TYPES.createAction_select(id))
  },
  unselectCustomerType: () => {
    dispatch(actionCreators.CUSTOMER_TYPES.createAction_unselect())
  },
  fetchCurrency: () => {
    dispatch(thunkCreators.currencytypes.createThunk_Currency_LIST())
  },
  selectCurrency: (id) => {
    dispatch(actionCreators.CURRENCY.createAction_select(id))
  },
  unselectCurrency: () => {
    dispatch(actionCreators.CURRENCY.createAction_unselect())
  }
});

export default connect(mapStateToProps, mapDispatchToProps);
