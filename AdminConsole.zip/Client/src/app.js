import React from 'react';
import AppBar from './components/appBar';
import AppNav from './components/appNav';
import { Switch, Route } from "react-router-dom";
import PageCustomerTypes from './pages/page.customer-types';
import PageLandingPage from './pages/page.landing-page';
import PageCurrency from './pages/page.currency';

const App = ({
  customerTypes,
  setNavigation,
  ui,
  unsetNavigation,
  fetchCustomerTypes,
  selectCustomerType,
  unselectCustomerType,
  currency,
  fetchCurrency,
  selectCurrency,
  unselectCurrency,
}) => {
  const navData = [
    { title: 'Payment profile', route: '#' },
    { title: 'Merchant configuration', route: '#' },
    { title: 'Legal entity', route: '#' },
    { title: 'RaiseNow widget', route: '#' },
    { title: 'Payment profile member', route: '#' },
    { title: 'Country', route: '#' },
    { title: 'Currency', route: '/currency' },
    { title: 'Transaction flow', route: '#' },
    { title: 'Transaction types', route: '#' },
    { title: 'Customer-Types', route: '/customer-types' },
    { title: 'Country currency mapping', route: '/countries-currencies' },
    { title: 'Bank account', route: '#' },
    { title: 'Bank account assignment', route: '#' },
    { title: 'Request source', route: '/requestsource' },
    { title: 'Privacy policy', route: '/privacypolicy' },
  ];

  return (
    <>
      <AppBar setNavigation={setNavigation} />
      <AppNav navData={navData} showNav={ui.showNav} unsetNavigation={unsetNavigation} />
      <Switch>

        <Route path="/currency">
          <PageCurrency
            data={currency}
            handlers={{
              selectCurrency, unselectCurrency, fetchCurrency
            }} />
        </Route>
        <Route path="/customer-types">
          {/* <PageCustomerTypes
            data={customerTypes}
            handlers={{
              selectCustomerType, unselectCustomerType, fetchCustomerTypes
            }} /> */}
            <h1>Customer type</h1>
        </Route>
        <Route path="/countries-currencies">
          <h1>PageCountriesCurrencies</h1>
        </Route>
        <Route path="/requestsource">
          <h1>Page Request source</h1>
        </Route>
        <Route path="/privacypolicy">
          <h1>Privacy policy</h1>
        </Route>
        <Route path="/">
          <PageLandingPage />
        </Route>
        <Route>
          No match
        </Route>
      </Switch>
    </>
  );
};

export default App;
