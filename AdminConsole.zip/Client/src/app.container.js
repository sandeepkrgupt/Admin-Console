import "whatwg-fetch"

import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { ThemeProvider } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import { MemoryRouter as Router } from 'react-router-dom';

import store from './rdx/store';
import connector from './rdx/connector';
import theme from './components/theme';
import App from './app';

const ConnectedApp = connector(App);

const AppContainer = (
  <Provider store={store}>
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <ConnectedApp />
      </Router>
    </ThemeProvider>
  </Provider>
);

ReactDOM.render(
  AppContainer,
  document.querySelector('#appContainer'),
);
