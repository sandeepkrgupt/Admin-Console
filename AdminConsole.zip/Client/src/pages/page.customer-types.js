import React, { useReducer, useEffect } from 'react'
import ListView from '../components/common/listview'

import {
  Switch,
  Route,
  useRouteMatch,
  Link,
  useHistory,
} from "react-router-dom";

import { PrimaryButton } from '../components/common/buttons'

import AddEditCustomerType from '../components/customer-types/customer-types.add-edit'
import CustomerTypeDetail from '../components/customer-types/customer-types.detail'

const PageCustomerTypes = ({ data, handlers }) => {
  let match = useRouteMatch();
  let history = useHistory();

  useEffect(() => {
    handlers.fetchCustomerTypes();
    return function resetCustomerTypes() {
    }
  }, [])
  return (
    <>
      <div>
        <PrimaryButton component={Link} to={'/'}>Back to Main Menu</PrimaryButton>
      </div>
      <Switch>
        <Route path={'/customer-types/add'}>
          <AddEditCustomerType
            customerType={{ id: null, code: "", type: "", subtype: "" }}
            onCancel={() => {
              history.push('/customer-types')
            }}
            onSave={() => {

            }} />
        </Route>
        <Route path={'/customer-types/edit/:id'}>
          <AddEditCustomerType
            customerType={null}
            onCancel={() => {
              history.push('/customer-types')
            }}
            onSave={() => {

            }} />
        </Route>
        <Route path={'/customer-types/detail/:id'}>
          <CustomerTypeDetail customerType={data.list.filter(ct => ct.id == data.selectedId)[0]} />
        </Route>
        <Route path={'/customer-types'}>
          <PrimaryButton component={Link} to={'/customer-types/add'}>Add Customer Type</PrimaryButton>
          <ListView
            rows={data.list}
            cols={[
              { title: "Customer Code", mappedTo: "id" },
              { title: "Customer Type", mappedTo: "type" },
              { title: "Customer Subtype", mappedTo: "subtype" },
              { title: "Status", mappedTo: "status" },
              { title: "Last Modified", mappedTo: "lastModified" },
            ]}
            onSelect={(row) => {
              handlers.selectCustomerType(row.id)
              history.push(`/customer-types/detail/${row.id}`)
            }}
            onAction={(action) => {
              console.log(action)
            }}
            sort={state.sort}
            />
        </Route>
        <Route>
          {match.path} - {match.url}
        </Route>
      </Switch>
    </>
  )
}

export default PageCustomerTypes;