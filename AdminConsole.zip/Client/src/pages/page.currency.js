import React, { useReducer, useEffect } from 'react'
import ListView from '../components/common/listview'
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import { Typography } from '@material-ui/core';

import {
  Switch,
  Route,
  useRouteMatch,
  Link,
  useHistory, NavLink
} from "react-router-dom";

import { PrimaryButton, CustomBackButton } from '../components/common/buttons';

const useStyles = makeStyles((theme) => ({
  root: {
    '& > *': {
      paddingLeft: theme.spacing(4),
      paddingRight: theme.spacing(4),
    },
    pagetitle:{
      color: '#0c3c7c',
      fontWeight: 'bold',
  }
  },
}));

const PageCurrency = ({ data, handlers }) => {
  const classes = useStyles();
  let match = useRouteMatch();
  let history = useHistory();

  useEffect(() => {
    handlers.fetchCurrency();
    return function resetCurrency() {
    }
  }, [])
  return (
    <>
      <div className={classes.root}>

        {/* <CustomBackButton component={Link} to={'/'}>Back to Main Menu</CustomBackButton> */}
        <NavLink style={{ color: '#0c3c7c', padding:30, textDecoration: 'none'}} to={'/'}>Back to Main Menu</NavLink>
        <Typography variant='h5' classes={{ root: classes.pagetitle }}>Currency</Typography>

        {/* <div><h2>Currency</h2></div> */}
        <Switch>


          <Route path={'/currency/add'}>
            {/* <AddEditCurrency
            currency={{ id: null, code: "", type: "", subtype: "" }}
            onCancel={() => {
              history.push('/currency')
            }}
            onSave={() => {

            }} /> */}
          </Route>
          <Route path={'/currency/edit/:id'}>
            {/* <AddEditCurrency
            currency={null}
            onCancel={() => {
              history.push('/currency')
            }}
            onSave={() => {

            }} /> */}
          </Route>
          <Route path={'/currency/detail/:id'}>
            {/* <CurrencyDetail currency={data.list.filter(ct => ct.id == data.selectedId)[0]} /> */}
          </Route>
          <Route path={'/currency'}>
            <PrimaryButton component={Link} to={'/currency/add'}>ADD</PrimaryButton>
            <ListView
              rows={data.list}
              cols={[
                { title: "Currency Key", mappedTo: "CurrencyKey" },
                { title: "Currency", mappedTo: "CurrencyName" },
                { title: "Currency Code", mappedTo: "CurrencyCode" },
                { title: "Status", mappedTo: "IsDeleted" },
                { title: "Last Modified", mappedTo: "DateModified" },
              ]}
              onSelect={(row) => {
                handlers.selectCurrency(row.CurrencyKey)
                history.push(`/currency/detail/${row.CurrencyKey}`)
              }}
              onAction={(action) => {
                console.log(action)
              }}
            />
          </Route>
          <Route>
            {match.path} - {match.url}
          </Route>
        </Switch>
      </div>
    </>
  )
}

export default PageCurrency;