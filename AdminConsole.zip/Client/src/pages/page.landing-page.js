import React, { useReducer, useEffect } from 'react'
import { makeStyles } from '@material-ui/core/styles';
import { Typography } from '@material-ui/core';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Divider from '@material-ui/core/Divider';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import { Link } from 'react-router-dom'

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
        maxWidth: 270,
        backgroundColor: '#eeeeee',
        color: '#1e5a9d',
    },
    container: {
        paddingTop: theme.spacing(4),
        paddingBottom: theme.spacing(4),
    },
    containerSpacing: {
        paddingTop: '8',
        paddingLeft: '20',
    },
    listItemText: {
        fontWeight: 'bold'
    },
    listItemTextFooter: {
        fontWeight: 'bold',
        fontSize: '14',
        color: '#1e5a9d',
    },
    dividerColor: {
        paddingTop: 5, backgroundColor: 'white',
    },
    dividerPadding: {
        paddingTop: 2,
    },
    pagetitle:{
        paddingBottom: 20,
        color: '#0c3c7c',
        fontWeight: 'bold',
    }
}));

const PageLandingPage = () => {
    const classes = useStyles();
    return (
        <>
            <Box ml={14} mt={6} p={2}>
                <Typography variant='h5' classes={{ root: classes.pagetitle }}>Donation & Payment Administration</Typography>
                <Grid container >
                    <Grid item xs={6} md={6} lg={3}>
                        <List component="nav" className={classes.root} aria-label="mailbox folders">
                            <ListItem button>
                                <ListItemText classes={{ primary: classes.listItemText }} primary="PAYMENT PROFILE" />
                            </ListItem>
                            <Divider classes={{ root: classes.dividerColor }} />
                            <ListItem button>
                                <ListItemText classes={{ primary: classes.listItemText }} primary="Legal entity" />
                            </ListItem>
                            <Divider classes={{ root: classes.dividerColor }} />
                            <ListItem button>
                                <ListItemText classes={{ primary: classes.listItemText }} primary="Merchant configuration" />
                            </ListItem>
                            <Divider classes={{ root: classes.dividerColor }} />
                            <ListItem button>
                                <ListItemText classes={{ primary: classes.listItemText }} primary="RaiseNow" />
                            </ListItem>
                        </List>
                    </Grid>
                    {/* Recent Deposits */}
                    <Grid item xs={6} md={6} lg={3}>
                        <List component="nav" className={classes.root}>
                            <ListItem button>
                                <ListItemText classes={{ primary: classes.listItemText }} primary="PAYMENT PROFILE MEMBER" />
                            </ListItem>
                            <Divider classes={{ root: classes.dividerColor }} />
                            <ListItem button >
                                <ListItemText classes={{ primary: classes.listItemText }} primary="Country" />
                            </ListItem>
                            <Divider classes={{ root: classes.dividerColor }} />

                            <ListItem button component={Link} to={'/currency'}>
                                <ListItemText classes={{ primary: classes.listItemText }} primary="Currency" />
                            </ListItem>

                            <Divider classes={{ root: classes.dividerColor }} />

                            <ListItem button>
                                <ListItemText classes={{ primary: classes.listItemText }} primary="Transaction flow" />
                            </ListItem>
                            <Divider classes={{ root: classes.dividerColor }} />
                            <ListItem button>
                                <ListItemText classes={{ primary: classes.listItemText }} primary="Transaction types" />
                            </ListItem>
                            <Divider classes={{ root: classes.dividerColor }} />
                            <ListItem button>
                                <ListItemText classes={{ primary: classes.listItemText }} primary="Country currency mapping" />
                            </ListItem>
                            <Divider classes={{ root: classes.dividerColor }} />
                            <ListItem button component={Link} to={'/customer-types'}>
                                <ListItemText classes={{ primary: classes.listItemText }} primary="Customer type" />
                            </ListItem>
                        </List>
                    </Grid>
                    <Grid item xs={6} md={6} lg={6}>
                        <List component="nav" className={classes.root}>
                            <ListItem button>
                                <ListItemText classes={{ primary: classes.listItemText }} primary="Bank account" />
                            </ListItem>
                            <Divider classes={{ root: classes.dividerColor }} />
                            <ListItem button >
                                <ListItemText classes={{ primary: classes.listItemText }} primary="Bank account assignment" />
                            </ListItem>
                            <Divider classes={{ root: classes.dividerColor }} />

                            <ListItem button component={Link} >
                                <ListItemText classes={{ primary: classes.listItemText }} primary="Request source" />
                            </ListItem>

                            <Divider classes={{ root: classes.dividerColor }} />

                            <ListItem button>
                                <ListItemText classes={{ primary: classes.listItemText }} primary="Privacy policy" />
                            </ListItem>
                        </List>
                    </Grid>
                </Grid>
            </Box>
        </>
    )
}

export default PageLandingPage;